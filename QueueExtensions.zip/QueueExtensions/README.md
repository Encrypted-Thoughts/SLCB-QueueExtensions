# SLCB-QueueExtensions
Extends existing queue functionality.
