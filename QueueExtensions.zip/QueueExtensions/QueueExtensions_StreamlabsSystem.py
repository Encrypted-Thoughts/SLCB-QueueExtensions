#---------------------------------------
#   Import Libraries
#---------------------------------------
import clr, System, json, codecs, os
clr.AddReference(
    [asm for asm in System.AppDomain.CurrentDomain.GetAssemblies() if "AnkhBotR2" in str(asm)][0]    
)
import AnkhBotR2

clr.AddReference("System.Windows.Forms")
from System.Windows.Forms.MessageBox import Show
msgbox = lambda obj: show(str(obj))

#---------------------------------------
#   [Required] Script Information
#---------------------------------------
ScriptName = "Queue Extensions"
Website = "twitch.tv/encryptedthoughts"
Description = "Extends existing streamlabs queue functionality."
Creator = "EncryptedThoughts"
Version = "1.0.0"

# ---------------------------------------
#	Set Variables
# ---------------------------------------
SettingsFile = os.path.join(os.path.dirname(__file__), "settings.json")
ReadMe = os.path.join(os.path.dirname(__file__), "README.md")
ScriptSettings = None

# ---------------------------------------
#	Script Classes
# ---------------------------------------
class Settings(object):
    def __init__(self, settingsfile=None):
        with codecs.open(settingsfile, encoding="utf-8-sig", mode="r") as f:
            self.__dict__ = json.load(f, encoding="utf-8")

    def Reload(self, jsonData):
        self.__dict__ = json.loads(jsonData, encoding="utf-8")

#---------------------------------------
#   [Required] Initialize Data / Load Only
#---------------------------------------
def Init():
    global ScriptSettings
    ScriptSettings = Settings(SettingsFile)

    global_manager - AnkhBotR2.Managers.GlobalManager.Instance
    vm_locator = global_manager.VMLocator
    queue = vm_locator.Queue

    msgbox(queue)

    return

# ---------------------------------------
# Chatbot Save Settings Function
# ---------------------------------------
def ReloadSettings(jsondata):
    ScriptSettings.Reload(jsondata)
    return

def Execute(data):
    return

def Tick():
    return

# ---------------------------------------
# Script UI Button Functions
# ---------------------------------------
def OpenReadMe():
    os.startfile(ReadMeFile)
    return
